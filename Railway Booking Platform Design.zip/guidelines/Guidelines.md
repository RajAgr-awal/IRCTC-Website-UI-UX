# IRCTC Rail Booking Platform — Design System

## Overview

A modern, premium, government-grade railway booking platform that reimagines the IRCTC experience with clean SaaS aesthetics, accessibility-first design, and a fast booking workflow serving millions of passengers daily.

## Design Principles

1. **Trust & Reliability** — Professional design language that instills confidence in a national transportation system
2. **Efficiency First** — Streamlined booking flow that minimizes steps and cognitive load
3. **Accessibility** — WCAG AA compliant with high contrast ratios and clear visual hierarchy
4. **Mobile-Responsive** — Seamless experience across all device sizes
5. **Visual Clarity** — Clean layouts with generous whitespace and clear information hierarchy

## Color Palette

### Primary Colors
- **Navy** `#0A1628` — Primary text, navigation, trust anchor
- **Blue** `#1B3A7A` — Primary interactive elements, buttons, links
- **Orange** `#F97316` — Accent color for CTAs and highlights

### Background & Surfaces
- **Background** `#FFFFFF` — Page background
- **Card** `#F8FAFF` — Card surfaces, subtle elevation
- **Border** `#D1DCF5` — Hairline rules and dividers

### Text Colors
- **Primary Text** `#0A1628` — Headings, important content
- **Secondary Text** `#6B7FA3` — Supporting text, labels, captions

### Status Colors
- **Success** `#22C55E` — Available seats, confirmations
- **Warning** `#F59E0B` — Waitlist status
- **Error** `#EF4444` — Full trains, validation errors

## Typography

### Font Families
- **Headings** — Sora (Google Fonts)
- **Body** — DM Sans (Google Fonts)

### Type Scale
- **H1** — 48px Bold (Hero headlines)
- **H2** — 32px Bold (Section titles)
- **H3** — 24px SemiBold (Card titles, subsections)
- **Body** — 16px Regular (Main content)
- **Caption** — 12px Medium (Small labels)

## Layout & Spacing

### Container
- **Max Width** — 1280px (7xl)
- **Padding** — 16px mobile, 24px tablet, 32px desktop

### Responsive Breakpoints
- **Mobile** — < 768px (single column, stacked navigation)
- **Tablet** — 768px - 1023px (2-column grids)
- **Desktop** — ≥ 1024px (full layout with sidebar filters)

## Components

### Cards
- **Background** — `#F8FAFF`
- **Border** — 1px solid `#D1DCF5`
- **Radius** — 12px-16px
- **Padding** — 24px

### Buttons

**Primary (Accent)**
- Background: `#F97316`
- Text: White
- Padding: 16px 24px
- Radius: 12px

**Secondary (Primary)**
- Background: `#1B3A7A`
- Text: White
- Padding: 16px 24px
- Radius: 12px

### Form Inputs
- Background: `#FFFFFF`
- Border: 1px solid `#D1DCF5`
- Radius: 12px
- Padding: 12px 16px
- Focus ring: 2px `#1B3A7A`

---

This design system creates a premium, trustworthy, and efficient railway booking experience that modernizes government digital services while maintaining the scale and reliability required for millions of daily users.
