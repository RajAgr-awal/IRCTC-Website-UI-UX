import { useState } from "react";
import { ArrowRight, Train, Search, FileText, Calendar, MapPin, Users, Shield, Globe, ChevronDown, Filter, Clock, IndianRupee, User, Phone, Mail, CheckCircle2, CreditCard, Smartphone, Wallet, Building2, Download, Share2, CalendarPlus, Menu, X, ChevronRight } from "lucide-react";

type Screen = "home" | "search-results" | "passenger-details" | "review" | "payment" | "confirmation";
type TripType = "one-way" | "round-trip";
type TrainClass = "1A" | "2A" | "3A" | "SL" | "2S";
type BookingStep = 1 | 2 | 3 | 4;

interface SearchParams {
  from: string;
  to: string;
  date: string;
  trainClass: TrainClass;
}

interface Passenger {
  name: string;
  age: string;
  gender: string;
  mobile: string;
  email: string;
  berth: string;
}

interface Train {
  number: string;
  name: string;
  departure: string;
  arrival: string;
  duration: string;
  availability: "AVL" | "WL" | "FULL";
  waitlist?: number;
  fare: number;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("home");
  const [tripType, setTripType] = useState<TripType>("one-way");
  const [searchParams, setSearchParams] = useState<SearchParams>({
    from: "",
    to: "",
    date: "",
    trainClass: "3A"
  });
  const [selectedTrain, setSelectedTrain] = useState<Train | null>(null);
  const [passenger, setPassenger] = useState<Passenger>({
    name: "",
    age: "",
    gender: "Male",
    mobile: "",
    email: "",
    berth: "Lower"
  });
  const [bookingStep, setBookingStep] = useState<BookingStep>(1);
  const [pnr] = useState("2468135790");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const trains: Train[] = [
    { number: "12301", name: "Rajdhani Express", departure: "16:55", arrival: "08:35", duration: "15h 40m", availability: "AVL", fare: 2450 },
    { number: "12951", name: "Mumbai Rajdhani", departure: "17:35", arrival: "09:15", duration: "15h 40m", availability: "WL", waitlist: 23, fare: 2380 },
    { number: "12009", name: "Shatabdi Express", departure: "06:00", arrival: "14:45", duration: "8h 45m", availability: "AVL", fare: 1850 },
    { number: "12423", name: "Dibrugarh Rajdhani", departure: "22:10", arrival: "13:50", duration: "15h 40m", availability: "FULL", fare: 2560 },
    { number: "12215", name: "Bandra Terminus Garib Rath", departure: "14:20", arrival: "05:40", duration: "15h 20m", availability: "AVL", fare: 1650 },
  ];

  if (currentScreen === "home") {
    return (
      <div className="min-h-screen bg-background" style={{ fontFamily: "var(--font-body)" }}>
        {/* Navigation */}
        <nav className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center gap-2" style={{ fontFamily: "var(--font-heading)" }}>
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <Train className="w-6 h-6 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold text-foreground">IRCTC Rail</span>
              </div>

              <div className="hidden md:flex items-center gap-8">
                <a href="#" className="text-sm font-medium text-foreground hover:text-primary transition-colors">Trains</a>
                <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">PNR Status</a>
                <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">My Bookings</a>
                <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Help</a>
                <button className="px-6 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all">
                  Login
                </button>
              </div>

              <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {mobileMenuOpen && (
            <div className="md:hidden border-t border-border bg-background">
              <div className="px-4 py-4 space-y-3">
                <a href="#" className="block text-sm font-medium text-foreground">Trains</a>
                <a href="#" className="block text-sm font-medium text-muted-foreground">PNR Status</a>
                <a href="#" className="block text-sm font-medium text-muted-foreground">My Bookings</a>
                <a href="#" className="block text-sm font-medium text-muted-foreground">Help</a>
                <button className="w-full px-6 py-2 bg-primary text-primary-foreground rounded-lg font-medium">
                  Login
                </button>
              </div>
            </div>
          )}
        </nav>

        {/* Hero Section */}
        <div className="relative overflow-hidden bg-gradient-to-br from-[#0A1628] via-[#1B3A7A] to-[#0A1628] text-white">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-primary rounded-full blur-3xl"></div>
          </div>

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm mb-6 border border-white/20">
                <Train className="w-4 h-4" />
                <span>Indian Railways • Booking Platform</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6" style={{ fontFamily: "var(--font-heading)" }}>
                Travel Smarter Across India
              </h1>

              <p className="text-lg sm:text-xl text-white/80 max-w-2xl mx-auto">
                Book train tickets, check PNR status, explore schedules, and manage journeys from one modern platform.
              </p>
            </div>

            {/* Search Widget */}
            <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-2xl p-6 sm:p-8">
              <div className="flex gap-4 mb-6 border-b border-border pb-4">
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-sm">
                  Book Ticket
                </button>
                <button className="px-4 py-2 text-muted-foreground hover:text-foreground font-medium text-sm transition-colors">
                  PNR Status
                </button>
                <button className="px-4 py-2 text-muted-foreground hover:text-foreground font-medium text-sm transition-colors">
                  Trains
                </button>
              </div>

              <div className="flex gap-4 mb-6">
                <button
                  onClick={() => setTripType("one-way")}
                  className={`px-4 py-2 rounded-lg font-medium text-sm transition-all ${
                    tripType === "one-way" ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/50"
                  }`}
                >
                  One Way
                </button>
                <button
                  onClick={() => setTripType("round-trip")}
                  className={`px-4 py-2 rounded-lg font-medium text-sm transition-all ${
                    tripType === "round-trip" ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/50"
                  }`}
                >
                  Round Trip
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">From Station</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input
                      type="text"
                      placeholder="Mumbai Central"
                      value={searchParams.from}
                      onChange={(e) => setSearchParams({ ...searchParams, from: e.target.value })}
                      className="w-full pl-11 pr-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">To Station</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input
                      type="text"
                      placeholder="New Delhi"
                      value={searchParams.to}
                      onChange={(e) => setSearchParams({ ...searchParams, to: e.target.value })}
                      className="w-full pl-11 pr-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Date of Journey</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input
                      type="date"
                      value={searchParams.date}
                      onChange={(e) => setSearchParams({ ...searchParams, date: e.target.value })}
                      className="w-full pl-11 pr-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Class</label>
                  <div className="relative">
                    <select
                      value={searchParams.trainClass}
                      onChange={(e) => setSearchParams({ ...searchParams, trainClass: e.target.value as TrainClass })}
                      className="w-full px-4 py-3 bg-input-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring appearance-none"
                    >
                      <option value="1A">First AC (1A)</option>
                      <option value="2A">Second AC (2A)</option>
                      <option value="3A">Third AC (3A)</option>
                      <option value="SL">Sleeper (SL)</option>
                      <option value="2S">Second Sitting (2S)</option>
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
                  </div>
                </div>
              </div>

              <button
                onClick={() => setCurrentScreen("search-results")}
                className="w-full py-4 bg-accent hover:bg-accent/90 text-accent-foreground rounded-xl font-semibold text-lg transition-all flex items-center justify-center gap-2 group"
              >
                <Search className="w-5 h-5" />
                Search Trains
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              <div className="flex flex-wrap gap-2 mt-6">
                <button className="px-4 py-2 bg-secondary text-foreground rounded-lg text-sm hover:bg-secondary/80 transition-colors">
                  Recent
                </button>
                <button className="px-4 py-2 bg-secondary text-foreground rounded-lg text-sm hover:bg-secondary/80 transition-colors">
                  Saved Routes
                </button>
                <button className="px-4 py-2 bg-secondary text-foreground rounded-lg text-sm hover:bg-secondary/80 transition-colors">
                  Popular Routes
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="border-b border-border bg-card">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { label: "Trains Daily", value: "14,000+", icon: Train },
                { label: "Passengers Daily", value: "8M+", icon: Users },
                { label: "Stations", value: "7,349", icon: MapPin },
                { label: "Secure Payments", value: "100%", icon: Shield }
              ].map((stat, i) => (
                <div key={i} className="text-center">
                  <stat.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                  <div className="text-3xl font-bold text-foreground mb-1" style={{ fontFamily: "var(--font-heading)" }}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Services Section */}
        <div className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12" style={{ fontFamily: "var(--font-heading)" }}>
              Our Services
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Train, title: "Ticket Booking", desc: "Book train tickets across India with ease and convenience" },
                { icon: FileText, title: "PNR Status", desc: "Track your booking status and seat confirmation instantly" },
                { icon: Calendar, title: "Season Pass", desc: "Get monthly passes for regular commuters at best rates" },
                { icon: Globe, title: "Rail Tourism", desc: "Explore tourist trains and special packages across India" }
              ].map((service, i) => (
                <div
                  key={i}
                  className="p-6 bg-card rounded-2xl border border-border hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group cursor-pointer"
                >
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary group-hover:scale-110 transition-all">
                    <service.icon className="w-6 h-6 text-primary group-hover:text-primary-foreground transition-colors" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2" style={{ fontFamily: "var(--font-heading)" }}>
                    {service.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {service.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="bg-foreground text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p className="text-sm text-white/60">
              © 2026 Indian Railway Catering and Tourism Corporation. All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    );
  }

  if (currentScreen === "search-results") {
    return (
      <div className="min-h-screen bg-background" style={{ fontFamily: "var(--font-body)" }}>
        {/* Sticky Search Bar */}
        <div className="sticky top-0 z-50 bg-background border-b border-border shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <button
                onClick={() => setCurrentScreen("home")}
                className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1"
              >
                ← Back
              </button>
              <div className="flex-1 flex flex-wrap items-center gap-3 text-sm">
                <span className="font-semibold text-foreground">{searchParams.from || "Mumbai"}</span>
                <ArrowRight className="w-4 h-4 text-muted-foreground" />
                <span className="font-semibold text-foreground">{searchParams.to || "New Delhi"}</span>
                <span className="text-muted-foreground">•</span>
                <span className="text-muted-foreground">{searchParams.date || "Jun 15, 2026"}</span>
                <span className="text-muted-foreground">•</span>
                <span className="text-muted-foreground">{searchParams.trainClass}</span>
              </div>
              <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90">
                Modify Search
              </button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters Sidebar */}
            <div className="lg:w-64 shrink-0">
              <div className="bg-card rounded-xl border border-border p-6 sticky top-24">
                <div className="flex items-center gap-2 mb-6">
                  <Filter className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>Filters</h3>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-3">Class</h4>
                    <div className="space-y-2">
                      {["1A", "2A", "3A", "SL", "2S"].map(cls => (
                        <label key={cls} className="flex items-center gap-2 cursor-pointer">
                          <input type="checkbox" className="rounded border-border" />
                          <span className="text-sm text-muted-foreground">{cls}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-3">Departure Time</h4>
                    <div className="space-y-2">
                      {["Morning (6-12)", "Afternoon (12-18)", "Evening (18-24)", "Night (0-6)"].map(time => (
                        <label key={time} className="flex items-center gap-2 cursor-pointer">
                          <input type="checkbox" className="rounded border-border" />
                          <span className="text-sm text-muted-foreground">{time}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-3">Availability</h4>
                    <div className="space-y-2">
                      {["Available", "Waitlist", "Show Full"].map(avl => (
                        <label key={avl} className="flex items-center gap-2 cursor-pointer">
                          <input type="checkbox" className="rounded border-border" defaultChecked={avl !== "Show Full"} />
                          <span className="text-sm text-muted-foreground">{avl}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Train Results */}
            <div className="flex-1">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>
                  {trains.length} Trains Available
                </h2>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Sort by:</span>
                  <select className="px-3 py-2 bg-card border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                    <option>Cheapest</option>
                    <option>Fastest</option>
                    <option>Earliest Departure</option>
                  </select>
                </div>
              </div>

              <div className="space-y-4">
                {trains.map((train) => (
                  <div
                    key={train.number}
                    className="bg-card rounded-xl border border-border p-6 hover:shadow-lg transition-all duration-300"
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center gap-6">
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="text-lg font-semibold text-foreground mb-1" style={{ fontFamily: "var(--font-heading)" }}>
                              {train.name}
                            </h3>
                            <span className="text-sm text-muted-foreground">#{train.number}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-8">
                          <div>
                            <div className="text-2xl font-bold text-foreground">{train.departure}</div>
                            <div className="text-sm text-muted-foreground mt-1">Mumbai</div>
                          </div>

                          <div className="flex-1 flex flex-col items-center">
                            <div className="text-sm text-muted-foreground mb-1">{train.duration}</div>
                            <div className="w-full h-0.5 bg-border relative">
                              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-primary rounded-full"></div>
                            </div>
                            <Clock className="w-4 h-4 text-muted-foreground mt-1" />
                          </div>

                          <div>
                            <div className="text-2xl font-bold text-foreground">{train.arrival}</div>
                            <div className="text-sm text-muted-foreground mt-1">New Delhi</div>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end gap-4">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            {train.availability === "AVL" && (
                              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                                Available
                              </span>
                            )}
                            {train.availability === "WL" && (
                              <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium">
                                WL {train.waitlist}
                              </span>
                            )}
                            {train.availability === "FULL" && (
                              <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium">
                                Full
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1 text-2xl font-bold text-foreground">
                            <IndianRupee className="w-5 h-5" />
                            {train.fare}
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            setSelectedTrain(train);
                            setCurrentScreen("passenger-details");
                          }}
                          disabled={train.availability === "FULL"}
                          className="px-6 py-3 bg-accent hover:bg-accent/90 text-accent-foreground rounded-xl font-semibold disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                        >
                          Book Now
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (currentScreen === "passenger-details") {
    return (
      <div className="min-h-screen bg-background" style={{ fontFamily: "var(--font-body)" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={() => setCurrentScreen("search-results")}
            className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1 mb-8"
          >
            ← Back to results
          </button>

          {/* Progress Indicator */}
          <div className="mb-12">
            <div className="flex items-center justify-between mb-4">
              {[
                { step: 1, label: "Passenger" },
                { step: 2, label: "Preferences" },
                { step: 3, label: "Review" },
                { step: 4, label: "Payment" }
              ].map((item, i) => (
                <div key={i} className="flex items-center flex-1">
                  <div className="flex flex-col items-center flex-1">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold mb-2 ${
                      bookingStep >= item.step ? "bg-primary text-primary-foreground" : "bg-card border-2 border-border text-muted-foreground"
                    }`}>
                      {item.step}
                    </div>
                    <span className="text-sm font-medium text-foreground hidden sm:block">{item.label}</span>
                  </div>
                  {i < 3 && (
                    <div className={`h-0.5 flex-1 -mt-8 ${bookingStep > item.step ? "bg-primary" : "bg-border"}`}></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card rounded-2xl border border-border p-8">
            <h2 className="text-2xl font-bold text-foreground mb-6" style={{ fontFamily: "var(--font-heading)" }}>
              Passenger Details
            </h2>

            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input
                      type="text"
                      value={passenger.name}
                      onChange={(e) => setPassenger({ ...passenger, name: e.target.value })}
                      placeholder="Rajesh Kumar"
                      className="w-full pl-11 pr-4 py-3 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Age</label>
                  <input
                    type="number"
                    value={passenger.age}
                    onChange={(e) => setPassenger({ ...passenger, age: e.target.value })}
                    placeholder="28"
                    className="w-full px-4 py-3 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Gender</label>
                  <select
                    value={passenger.gender}
                    onChange={(e) => setPassenger({ ...passenger, gender: e.target.value })}
                    className="w-full px-4 py-3 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Mobile Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input
                      type="tel"
                      value={passenger.mobile}
                      onChange={(e) => setPassenger({ ...passenger, mobile: e.target.value })}
                      placeholder="+91 98765 43210"
                      className="w-full pl-11 pr-4 py-3 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input
                      type="email"
                      value={passenger.email}
                      onChange={(e) => setPassenger({ ...passenger, email: e.target.value })}
                      placeholder="rajesh@example.com"
                      className="w-full pl-11 pr-4 py-3 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Berth Preference</label>
                  <select
                    value={passenger.berth}
                    onChange={(e) => setPassenger({ ...passenger, berth: e.target.value })}
                    className="w-full px-4 py-3 bg-background border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option>Lower</option>
                    <option>Middle</option>
                    <option>Upper</option>
                    <option>Side Lower</option>
                    <option>Side Upper</option>
                  </select>
                </div>
              </div>

              <button
                onClick={() => setCurrentScreen("review")}
                className="w-full py-4 bg-accent hover:bg-accent/90 text-accent-foreground rounded-xl font-semibold text-lg transition-all flex items-center justify-center gap-2"
              >
                Continue to Review
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (currentScreen === "review") {
    const baseFare = selectedTrain?.fare || 2450;
    const tax = Math.round(baseFare * 0.05);
    const convenience = 50;
    const total = baseFare + tax + convenience;

    return (
      <div className="min-h-screen bg-background" style={{ fontFamily: "var(--font-body)" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={() => setCurrentScreen("passenger-details")}
            className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1 mb-8"
          >
            ← Back
          </button>

          <h2 className="text-3xl font-bold text-foreground mb-8" style={{ fontFamily: "var(--font-heading)" }}>
            Review Booking
          </h2>

          <div className="space-y-6">
            {/* Journey Summary */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4" style={{ fontFamily: "var(--font-heading)" }}>
                Journey Summary
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Train</span>
                  <span className="font-medium text-foreground">{selectedTrain?.name} ({selectedTrain?.number})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">From</span>
                  <span className="font-medium text-foreground">Mumbai Central</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">To</span>
                  <span className="font-medium text-foreground">New Delhi</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Date</span>
                  <span className="font-medium text-foreground">June 15, 2026</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Class</span>
                  <span className="font-medium text-foreground">{searchParams.trainClass}</span>
                </div>
              </div>
            </div>

            {/* Passenger Summary */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4" style={{ fontFamily: "var(--font-heading)" }}>
                Passenger Summary
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name</span>
                  <span className="font-medium text-foreground">{passenger.name || "Rajesh Kumar"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Age / Gender</span>
                  <span className="font-medium text-foreground">{passenger.age || "28"} / {passenger.gender}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Mobile</span>
                  <span className="font-medium text-foreground">{passenger.mobile || "+91 98765 43210"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Berth Preference</span>
                  <span className="font-medium text-foreground">{passenger.berth}</span>
                </div>
              </div>
            </div>

            {/* Fare Breakdown */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4" style={{ fontFamily: "var(--font-heading)" }}>
                Fare Breakdown
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Base Fare</span>
                  <span className="font-medium text-foreground">₹{baseFare}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">GST (5%)</span>
                  <span className="font-medium text-foreground">₹{tax}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Convenience Fee</span>
                  <span className="font-medium text-foreground">₹{convenience}</span>
                </div>
                <div className="border-t border-border pt-3 mt-3">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold text-foreground">Total Fare</span>
                    <span className="text-2xl font-bold text-foreground">₹{total}</span>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => setCurrentScreen("payment")}
              className="w-full py-4 bg-accent hover:bg-accent/90 text-accent-foreground rounded-xl font-semibold text-lg transition-all flex items-center justify-center gap-2"
            >
              Proceed to Payment
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (currentScreen === "payment") {
    const [selectedPayment, setSelectedPayment] = useState<string>("upi");

    return (
      <div className="min-h-screen bg-background" style={{ fontFamily: "var(--font-body)" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={() => setCurrentScreen("review")}
            className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1 mb-8"
          >
            ← Back
          </button>

          <h2 className="text-3xl font-bold text-foreground mb-8" style={{ fontFamily: "var(--font-heading)" }}>
            Select Payment Method
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            {[
              { id: "upi", icon: Smartphone, label: "UPI", desc: "Pay via UPI apps" },
              { id: "debit", icon: CreditCard, label: "Debit Card", desc: "Visa, Mastercard, RuPay" },
              { id: "credit", icon: CreditCard, label: "Credit Card", desc: "Visa, Mastercard" },
              { id: "netbanking", icon: Building2, label: "Net Banking", desc: "All major banks" },
              { id: "wallet", icon: Wallet, label: "Wallet", desc: "Paytm, PhonePe, Google Pay" }
            ].map((method) => (
              <button
                key={method.id}
                onClick={() => setSelectedPayment(method.id)}
                className={`p-6 rounded-xl border-2 transition-all text-left ${
                  selectedPayment === method.id
                    ? "border-primary bg-primary/5"
                    : "border-border bg-card hover:border-primary/50"
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    selectedPayment === method.id ? "bg-primary" : "bg-secondary"
                  }`}>
                    <method.icon className={`w-6 h-6 ${
                      selectedPayment === method.id ? "text-primary-foreground" : "text-foreground"
                    }`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground mb-1">{method.label}</h3>
                    <p className="text-sm text-muted-foreground">{method.desc}</p>
                  </div>
                  {selectedPayment === method.id && (
                    <CheckCircle2 className="w-6 h-6 text-primary" />
                  )}
                </div>
              </button>
            ))}
          </div>

          <div className="bg-card rounded-2xl border border-border p-6 mb-8">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <Shield className="w-5 h-5 text-green-600" />
              <span>Your payment is secure and encrypted with 256-bit SSL</span>
            </div>
          </div>

          <button
            onClick={() => setCurrentScreen("confirmation")}
            className="w-full py-4 bg-accent hover:bg-accent/90 text-accent-foreground rounded-xl font-semibold text-lg transition-all flex items-center justify-center gap-2"
          >
            Pay ₹{(selectedTrain?.fare || 2450) + Math.round((selectedTrain?.fare || 2450) * 0.05) + 50}
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  if (currentScreen === "confirmation") {
    return (
      <div className="min-h-screen bg-background" style={{ fontFamily: "var(--font-body)" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-green-100 rounded-full mb-6">
              <CheckCircle2 className="w-12 h-12 text-green-600" />
            </div>
            <h1 className="text-4xl font-bold text-foreground mb-4" style={{ fontFamily: "var(--font-heading)" }}>
              Booking Confirmed!
            </h1>
            <p className="text-lg text-muted-foreground">
              Your ticket has been booked successfully
            </p>
          </div>

          <div className="bg-card rounded-2xl border border-border p-8 mb-8">
            <div className="flex items-center justify-between mb-6 pb-6 border-b border-border">
              <div>
                <span className="text-sm text-muted-foreground">PNR Number</span>
                <div className="text-3xl font-bold text-foreground mt-1" style={{ fontFamily: "var(--font-heading)" }}>
                  {pnr}
                </div>
              </div>
              <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center">
                <Train className="w-8 h-8 text-primary-foreground" />
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <h3 className="font-semibold text-foreground mb-4" style={{ fontFamily: "var(--font-heading)" }}>
                Journey Details
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-sm text-muted-foreground">Train</span>
                  <p className="font-medium text-foreground">{selectedTrain?.name}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Train Number</span>
                  <p className="font-medium text-foreground">{selectedTrain?.number}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">From</span>
                  <p className="font-medium text-foreground">Mumbai Central</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">To</span>
                  <p className="font-medium text-foreground">New Delhi</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Date</span>
                  <p className="font-medium text-foreground">June 15, 2026</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Class</span>
                  <p className="font-medium text-foreground">{searchParams.trainClass}</p>
                </div>
              </div>
            </div>

            <div className="border-t border-border pt-6">
              <h3 className="font-semibold text-foreground mb-4" style={{ fontFamily: "var(--font-heading)" }}>
                Passenger Information
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-sm text-muted-foreground">Name</span>
                  <p className="font-medium text-foreground">{passenger.name || "Rajesh Kumar"}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Age</span>
                  <p className="font-medium text-foreground">{passenger.age || "28"}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Berth</span>
                  <p className="font-medium text-foreground">{passenger.berth} - Confirmed</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">Seat Number</span>
                  <p className="font-medium text-foreground">A1-42</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            <button className="flex items-center justify-center gap-2 px-6 py-4 bg-primary text-primary-foreground rounded-xl font-semibold hover:bg-primary/90 transition-all">
              <Download className="w-5 h-5" />
              Download Ticket
            </button>
            <button className="flex items-center justify-center gap-2 px-6 py-4 bg-card border border-border text-foreground rounded-xl font-semibold hover:bg-secondary transition-all">
              <Share2 className="w-5 h-5" />
              Share Ticket
            </button>
            <button className="flex items-center justify-center gap-2 px-6 py-4 bg-card border border-border text-foreground rounded-xl font-semibold hover:bg-secondary transition-all">
              <CalendarPlus className="w-5 h-5" />
              Add to Calendar
            </button>
          </div>

          <div className="text-center">
            <button
              onClick={() => setCurrentScreen("home")}
              className="text-primary hover:text-primary/80 font-semibold flex items-center justify-center gap-2 mx-auto"
            >
              <ChevronRight className="w-5 h-5 rotate-180" />
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}