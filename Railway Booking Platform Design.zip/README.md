
  # Railway Booking Platform Design

  This is a code bundle for Railway Booking Platform Design. The original project is available at https://www.figma.com/design/kZiJ17aSAwtRfBv3eBG1MX/Railway-Booking-Platform-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  